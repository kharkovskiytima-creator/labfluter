﻿\xEF\xBB\xBFunit Unit1;

{ Лабораторна робота №6. Проведення кореляційного аналізу.
  Парні та множинні коефіцієнти кореляції, детермінація, алгоритм
  Фаррара-Глобера, частинні коефіцієнти, покрокова регресія.
  Інтерфейс створюється програмно (див. BuildUI). }

interface

uses
  Winapi.Windows, System.SysUtils, System.Classes, System.Math, System.StrUtils,
  Vcl.Controls, Vcl.Forms, Vcl.StdCtrls, Vcl.ExtCtrls, Vcl.ComCtrls,
  Vcl.Grids, Vcl.Dialogs, Vcl.Graphics;

type
  TVec = array of Double;
  TMat = array of array of Double;

  TForm1 = class(TForm)
  private
    FPanel: TPanel;
    FCombo: TComboBox;
    FEditAlpha: TEdit;
    FBtnCalc, FBtnSave, FBtnCsv: TButton;
    FPages: TPageControl;
    FTabData, FTabRes: TTabSheet;
    FGrid: TStringGrid;
    FMemo: TMemo;
    FSave: TSaveDialog;
    procedure BuildUI;
    procedure Say(const S: string = '');
    procedure LoadVariant(Sender: TObject);
    procedure Calculate(Sender: TObject);
    procedure SaveReport(Sender: TObject);
    procedure SaveCsv(Sender: TObject);
    function ReadData(out D: TMat; out Msg: string): Boolean;
  public
    constructor Create(AOwner: TComponent); override;
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

const
  VarNames: array[0..3] of string = ('Y', 'X1', 'X2', 'X3');

  { Таблиця 6.2: N1..N4 для варіантів 1..21 }
  VarTable: array[0..20, 1..4] of Integer = (
    (7, 6, 1, 7), (7, 7, 2, 2), (2, 6, 8, 6), (7, 6, 4, 7), (4, 8, 3, 4),
    (3, 2, 6, 8), (3, 3, 3, 7), (4, 5, 6, 5), (7, 4, 2, 9), (8, 8, 1, 8),
    (7, 3, 6, 3), (4, 3, 7, 7), (3, 6, 6, 4), (4, 8, 5, 3), (3, 3, 4, 2),
    (5, 6, 8, 1), (8, 5, 7, 8), (7, 6, 1, 7), (7, 7, 2, 2), (2, 6, 8, 6),
    (7, 6, 4, 7));

  { Таблиця 6.1: значення = База + Знак * N[індекс] }
  YB: array[0..20] of Integer = (70, 75, 70, 73, 78, 69, 72, 75, 68, 78, 80, 78, 79, 75, 79, 82, 84, 81, 85, 86, 75);
  YN: array[0..20] of Integer = (4, 3, 1, 2, 4, 4, 1, 2, 1, 2, 4, 3, 1, 4, 2, 1, 4, 2, 3, 2, 2);
  X1B: array[0..20] of Integer = (32, 37, 33, 34, 36, 35, 34, 37, 32, 38, 40, 37, 38, 39, 40, 42, 44, 41, 45, 47, 37);
  X1N: array[0..20] of Integer = (4, 4, 2, 1, 2, 3, 4, 3, 1, 1, 1, 4, 4, 1, 2, 2, 3, 4, 4, 1, 3);
  X2B: array[0..20] of Integer = (5, 7, 6, 7, 6, 5, 6, 9, 5, 10, 11, 10, 12, 8, 9, 14, 15, 13, 16, 18, 9);
  X2N: array[0..20] of Integer = (4, 1, 3, 1, 4, 1, 3, 2, 3, 3, 2, 4, 4, 1, 4, 4, 2, 4, 3, 1, 2);
  X3B: array[0..20] of Integer = (25, 28, 26, 27, 30, 25, 26, 28, 29, 30, 32, 31, 31, 30, 32, 33, 34, 30, 34, 35, 28);
  X3N: array[0..20] of Integer = (2, 4, 4, 2, 2, 1, 1, 2, 4, 2, 1, 2, 3, 4, 1, 2, 4, 3, 1, 4, 2);

{ ====================== Спеціальні функції (розподіли) ====================== }

function LnGam(x: Double): Double;
const
  Cof: array[0..5] of Double = (76.18009172947146, -86.50532032941677,
    24.01409824083091, -1.231739572450155, 0.1208650973866179e-2,
    -0.5395239384953e-5);
var
  y, tmp, ser: Double;
  j: Integer;
begin
  y := x;
  tmp := x + 5.5;
  tmp := tmp - (x + 0.5) * Ln(tmp);
  ser := 1.000000000190015;
  for j := 0 to 5 do
  begin
    y := y + 1;
    ser := ser + Cof[j] / y;
  end;
  Result := -tmp + Ln(2.5066282746310005 * ser / x);
end;

function BetaCF(a, b, x: Double): Double;
const
  MaxIt = 500;
  Eps = 3E-14;
  FpMin = 1E-300;
var
  m, m2: Integer;
  aa, c, d, del, h, qab, qam, qap: Double;
begin
  qab := a + b;
  qap := a + 1;
  qam := a - 1;
  c := 1;
  d := 1 - qab * x / qap;
  if Abs(d) < FpMin then d := FpMin;
  d := 1 / d;
  h := d;
  for m := 1 to MaxIt do
  begin
    m2 := 2 * m;
    aa := m * (b - m) * x / ((qam + m2) * (a + m2));
    d := 1 + aa * d;
    if Abs(d) < FpMin then d := FpMin;
    c := 1 + aa / c;
    if Abs(c) < FpMin then c := FpMin;
    d := 1 / d;
    h := h * d * c;
    aa := -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2));
    d := 1 + aa * d;
    if Abs(d) < FpMin then d := FpMin;
    c := 1 + aa / c;
    if Abs(c) < FpMin then c := FpMin;
    d := 1 / d;
    del := d * c;
    h := h * del;
    if Abs(del - 1) < Eps then Break;
  end;
  Result := h;
end;

{ Регуляризована неповна бета-функція I_x(a,b) }
function BetaInc(a, b, x: Double): Double;
var
  bt: Double;
begin
  if x <= 0 then Exit(0);
  if x >= 1 then Exit(1);
  bt := Exp(LnGam(a + b) - LnGam(a) - LnGam(b) + a * Ln(x) + b * Ln(1 - x));
  if x < (a + 1) / (a + b + 2) then
    Result := bt * BetaCF(a, b, x) / a
  else
    Result := 1 - bt * BetaCF(b, a, 1 - x) / b;
end;

{ Двобічне p-значення розподілу Стьюдента }
function TwoSidedP(t: Double; df: Integer): Double;
begin
  Result := BetaInc(df / 2, 0.5, df / (df + t * t));
end;

{ Критичне значення Стьюдента (двобічне) — аналог СТЬЮДРАСПОБР }
function TCrit(alpha: Double; df: Integer): Double;
var
  lo, hi, mid: Double;
  it: Integer;
begin
  lo := 0;
  hi := 1000;
  for it := 1 to 200 do
  begin
    mid := (lo + hi) / 2;
    if TwoSidedP(mid, df) > alpha then lo := mid else hi := mid;
  end;
  Result := (lo + hi) / 2;
end;

function FUpperP(f: Double; d1, d2: Integer): Double;
begin
  Result := BetaInc(d2 / 2, d1 / 2, d2 / (d2 + d1 * f));
end;

{ Критичне значення Фішера — аналог FРАСПОБР }
function FCrit(alpha: Double; d1, d2: Integer): Double;
var
  lo, hi, mid: Double;
  it: Integer;
begin
  lo := 0;
  hi := 1E7;
  for it := 1 to 300 do
  begin
    mid := (lo + hi) / 2;
    if FUpperP(mid, d1, d2) > alpha then lo := mid else hi := mid;
  end;
  Result := (lo + hi) / 2;
end;

function GammaPSer(a, x: Double): Double;
var
  ap, sum, del: Double;
  n: Integer;
begin
  ap := a;
  sum := 1 / a;
  del := sum;
  for n := 1 to 2000 do
  begin
    ap := ap + 1;
    del := del * x / ap;
    sum := sum + del;
    if Abs(del) < Abs(sum) * 1E-15 then Break;
  end;
  Result := sum * Exp(-x + a * Ln(x) - LnGam(a));
end;

function GammaQCF(a, x: Double): Double;
const
  FpMin = 1E-300;
var
  i: Integer;
  an, b, c, d, del, h: Double;
begin
  b := x + 1 - a;
  c := 1 / FpMin;
  d := 1 / b;
  h := d;
  for i := 1 to 2000 do
  begin
    an := -i * (i - a);
    b := b + 2;
    d := an * d + b;
    if Abs(d) < FpMin then d := FpMin;
    c := b + an / c;
    if Abs(c) < FpMin then c := FpMin;
    d := 1 / d;
    del := d * c;
    h := h * del;
    if Abs(del - 1) < 1E-15 then Break;
  end;
  Result := Exp(-x + a * Ln(x) - LnGam(a)) * h;
end;

{ Верхній хвіст розподілу хі-квадрат }
function ChiUpperP(x: Double; k: Integer): Double;
var
  a, xx: Double;
begin
  a := k / 2;
  xx := x / 2;
  if xx <= 0 then Exit(1);
  if xx < a + 1 then
    Result := 1 - GammaPSer(a, xx)
  else
    Result := GammaQCF(a, xx);
end;

{ Критичне значення хі-квадрат — аналог ХИ2ОБР }
function ChiCrit(alpha: Double; k: Integer): Double;
var
  lo, hi, mid: Double;
  it: Integer;
begin
  lo := 0;
  hi := 1000;
  for it := 1 to 300 do
  begin
    mid := (lo + hi) / 2;
    if ChiUpperP(mid, k) > alpha then lo := mid else hi := mid;
  end;
  Result := (lo + hi) / 2;
end;

{ ============================ Лінійна алгебра =============================== }

function MatCopy(const A: TMat): TMat;
var
  i: Integer;
begin
  SetLength(Result, Length(A));
  for i := 0 to High(A) do
    Result[i] := Copy(A[i]);
end;

{ Визначник — аналог МОПРЕД }
function MatDet(const A: TMat): Double;
var
  M: TMat;
  n, i, j, k, p: Integer;
  f, t: Double;
begin
  M := MatCopy(A);
  n := Length(M);
  Result := 1;
  for k := 0 to n - 1 do
  begin
    p := k;
    for i := k + 1 to n - 1 do
      if Abs(M[i][k]) > Abs(M[p][k]) then p := i;
    if Abs(M[p][k]) < 1E-14 then Exit(0);
    if p <> k then
    begin
      for j := 0 to n - 1 do
      begin
        t := M[k][j];
        M[k][j] := M[p][j];
        M[p][j] := t;
      end;
      Result := -Result;
    end;
    Result := Result * M[k][k];
    for i := k + 1 to n - 1 do
    begin
      f := M[i][k] / M[k][k];
      for j := k to n - 1 do
        M[i][j] := M[i][j] - f * M[k][j];
    end;
  end;
end;

{ Обернена матриця — аналог МОБР (метод Гауса-Жордана) }
function MatInv(const A: TMat; out Ok: Boolean): TMat;
var
  n, i, j, k, p: Integer;
  M: TMat;
  t, f: Double;
begin
  n := Length(A);
  M := MatCopy(A);
  SetLength(Result, n);
  for i := 0 to n - 1 do
  begin
    SetLength(Result[i], n);
    for j := 0 to n - 1 do
      if i = j then Result[i][j] := 1 else Result[i][j] := 0;
  end;
  Ok := True;
  for k := 0 to n - 1 do
  begin
    p := k;
    for i := k + 1 to n - 1 do
      if Abs(M[i][k]) > Abs(M[p][k]) then p := i;
    if Abs(M[p][k]) < 1E-14 then
    begin
      Ok := False;
      Exit;
    end;
    if p <> k then
      for j := 0 to n - 1 do
      begin
        t := M[k][j]; M[k][j] := M[p][j]; M[p][j] := t;
        t := Result[k][j]; Result[k][j] := Result[p][j]; Result[p][j] := t;
      end;
    t := M[k][k];
    for j := 0 to n - 1 do
    begin
      M[k][j] := M[k][j] / t;
      Result[k][j] := Result[k][j] / t;
    end;
    for i := 0 to n - 1 do
      if i <> k then
      begin
        f := M[i][k];
        if f <> 0 then
          for j := 0 to n - 1 do
          begin
            M[i][j] := M[i][j] - f * M[k][j];
            Result[i][j] := Result[i][j] - f * Result[k][j];
          end;
      end;
  end;
end;

{ ============================== Статистика ================================== }

function AvgOf(const V: TVec): Double;
var
  i: Integer;
begin
  Result := 0;
  for i := 0 to High(V) do
    Result := Result + V[i];
  Result := Result / Length(V);
end;

{ Стандартне відхилення (n-1) — аналог СТАНДОТКЛОН }
function SdOf(const V: TVec): Double;
var
  i: Integer;
  m, s: Double;
begin
  m := AvgOf(V);
  s := 0;
  for i := 0 to High(V) do
    s := s + Sqr(V[i] - m);
  Result := Sqrt(s / (Length(V) - 1));
end;

{ Коефіцієнт парної кореляції — аналог КОРРЕЛ }
function CorrOf(const A, B: TVec): Double;
var
  i: Integer;
  ma, mb, sab, saa, sbb: Double;
begin
  ma := AvgOf(A);
  mb := AvgOf(B);
  sab := 0; saa := 0; sbb := 0;
  for i := 0 to High(A) do
  begin
    sab := sab + (A[i] - ma) * (B[i] - mb);
    saa := saa + Sqr(A[i] - ma);
    sbb := sbb + Sqr(B[i] - mb);
  end;
  if (saa = 0) or (sbb = 0) then Result := 0
  else Result := sab / Sqrt(saa * sbb);
end;

function Strength(r: Double): string;
begin
  r := Abs(r);
  if r < 0.3 then Result := 'слабкий'
  else if r <= 0.7 then Result := 'помірний'
  else Result := 'сильний';
end;

function SafeT(r: Double; df: Integer): Double;
begin
  if 1 - r * r < 1E-12 then Result := 1E9
  else Result := r * Sqrt(df) / Sqrt(1 - r * r);
end;

function InArr(const A: TArray<Integer>; v: Integer): Boolean;
var
  i: Integer;
begin
  Result := False;
  for i := 0 to High(A) do
    if A[i] = v then Exit(True);
end;

{ Множинна лінійна регресія методом найменших квадратів.
  D[0] — Y, Cols — індекси факторів у D. B[0] — вільний член. }
function Regress(const D: TMat; const Cols: TArray<Integer>;
  out B: TVec; out R2: Double): Boolean;
var
  n, k, i, a, c: Integer;
  AM, Inv: TMat;
  rhs, X: TVec;
  Ok: Boolean;
  sst, sse, my, pred: Double;
begin
  n := Length(D[0]);
  k := Length(Cols) + 1;
  SetLength(AM, k);
  for i := 0 to k - 1 do
  begin
    SetLength(AM[i], k);
    for c := 0 to k - 1 do AM[i][c] := 0;
  end;
  SetLength(rhs, k);
  for i := 0 to k - 1 do rhs[i] := 0;
  SetLength(X, k);
  for i := 0 to n - 1 do
  begin
    X[0] := 1;
    for a := 1 to k - 1 do X[a] := D[Cols[a - 1]][i];
    for a := 0 to k - 1 do
    begin
      rhs[a] := rhs[a] + X[a] * D[0][i];
      for c := 0 to k - 1 do
        AM[a][c] := AM[a][c] + X[a] * X[c];
    end;
  end;
  Inv := MatInv(AM, Ok);
  Result := Ok;
  if not Ok then Exit;
  SetLength(B, k);
  for a := 0 to k - 1 do
  begin
    B[a] := 0;
    for c := 0 to k - 1 do B[a] := B[a] + Inv[a][c] * rhs[c];
  end;
  my := AvgOf(D[0]);
  sst := 0; sse := 0;
  for i := 0 to n - 1 do
  begin
    pred := B[0];
    for a := 1 to k - 1 do pred := pred + B[a] * D[Cols[a - 1]][i];
    sse := sse + Sqr(D[0][i] - pred);
    sst := sst + Sqr(D[0][i] - my);
  end;
  if sst > 0 then R2 := 1 - sse / sst else R2 := 0;
end;

function Equation(const B: TVec; const Cols: TArray<Integer>): string;
var
  a: Integer;
begin
  Result := Format('Y = %.4f', [B[0]]);
  for a := 1 to High(B) do
    if B[a] >= 0 then
      Result := Result + Format(' + %.4f*%s', [B[a], VarNames[Cols[a - 1]]])
    else
      Result := Result + Format(' - %.4f*%s', [Abs(B[a]), VarNames[Cols[a - 1]]]);
end;

function ParseF(const S: string; out V: Double): Boolean;
var
  T: string;
begin
  T := Trim(S);
  T := StringReplace(T, ',', FormatSettings.DecimalSeparator, [rfReplaceAll]);
  T := StringReplace(T, '.', FormatSettings.DecimalSeparator, [rfReplaceAll]);
  Result := TryStrToFloat(T, V);
end;

{ ================================ Форма ===================================== }

constructor TForm1.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  BuildUI;
  LoadVariant(nil);
  Calculate(nil);
  FPages.ActivePage := FTabRes;
end;

procedure TForm1.BuildUI;
var
  i: Integer;
  L: TLabel;
begin
  Caption := 'Лабораторна робота №6 — Кореляційний аналіз';
  Width := 1020;
  Height := 740;
  Position := poScreenCenter;

  FPanel := TPanel.Create(Self);
  FPanel.Parent := Self;
  FPanel.Align := alTop;
  FPanel.Height := 48;
  FPanel.BevelOuter := bvNone;

  L := TLabel.Create(Self);
  L.Parent := FPanel;
  L.Left := 12; L.Top := 15;
  L.Caption := 'Варіант:';

  FCombo := TComboBox.Create(Self);
  FCombo.Parent := FPanel;
  FCombo.Left := 70; FCombo.Top := 11; FCombo.Width := 60;
  FCombo.Style := csDropDownList;
  for i := 1 to 21 do FCombo.Items.Add(IntToStr(i));
  FCombo.ItemIndex := 0;
  FCombo.OnChange := LoadVariant;

  L := TLabel.Create(Self);
  L.Parent := FPanel;
  L.Left := 150; L.Top := 15;
  L.Caption := 'Рівень значущості α:';

  FEditAlpha := TEdit.Create(Self);
  FEditAlpha.Parent := FPanel;
  FEditAlpha.Left := 275; FEditAlpha.Top := 11; FEditAlpha.Width := 55;
  FEditAlpha.Text := '0.05';

  FBtnCalc := TButton.Create(Self);
  FBtnCalc.Parent := FPanel;
  FBtnCalc.SetBounds(350, 9, 120, 30);
  FBtnCalc.Caption := 'Розрахувати';
  FBtnCalc.OnClick := Calculate;

  FBtnSave := TButton.Create(Self);
  FBtnSave.Parent := FPanel;
  FBtnSave.SetBounds(480, 9, 130, 30);
  FBtnSave.Caption := 'Зберегти звіт';
  FBtnSave.OnClick := SaveReport;

  FBtnCsv := TButton.Create(Self);
  FBtnCsv.Parent := FPanel;
  FBtnCsv.SetBounds(620, 9, 170, 30);
  FBtnCsv.Caption := 'Дані в CSV (для Excel)';
  FBtnCsv.OnClick := SaveCsv;

  FPages := TPageControl.Create(Self);
  FPages.Parent := Self;
  FPages.Align := alClient;

  FTabData := TTabSheet.Create(Self);
  FTabData.PageControl := FPages;
  FTabData.Caption := 'Вихідні дані';

  FTabRes := TTabSheet.Create(Self);
  FTabRes.PageControl := FPages;
  FTabRes.Caption := 'Результати розрахунку';

  FGrid := TStringGrid.Create(Self);
  FGrid.Parent := FTabData;
  FGrid.Align := alClient;
  FGrid.ColCount := 5;
  FGrid.RowCount := 22;
  FGrid.FixedCols := 1;
  FGrid.FixedRows := 1;
  FGrid.DefaultRowHeight := 24;
  FGrid.Options := [goFixedVertLine, goFixedHorzLine, goVertLine, goHorzLine,
    goEditing, goTabs, goColSizing];
  FGrid.ColWidths[0] := 70;
  for i := 1 to 4 do FGrid.ColWidths[i] := 190;
  FGrid.Cells[0, 0] := 'Місяць';
  FGrid.Cells[1, 0] := 'Y — Прибуток, грн.';
  FGrid.Cells[2, 0] := 'X1 — Фондовіддача, грн.';
  FGrid.Cells[3, 0] := 'X2 — Продуктивність праці';
  FGrid.Cells[4, 0] := 'X3 — Питомі інвестиції';

  FMemo := TMemo.Create(Self);
  FMemo.Parent := FTabRes;
  FMemo.Align := alClient;
  FMemo.ReadOnly := True;
  FMemo.ScrollBars := ssBoth;
  FMemo.WordWrap := False;
  FMemo.Font.Name := 'Consolas';
  FMemo.Font.Size := 10;

  FSave := TSaveDialog.Create(Self);
end;

procedure TForm1.Say(const S: string);
begin
  FMemo.Lines.Add(S);
end;

procedure TForm1.LoadVariant(Sender: TObject);
var
  v, i: Integer;
  N: array[1..4] of Integer;
begin
  v := FCombo.ItemIndex;
  for i := 1 to 4 do N[i] := VarTable[v, i];
  for i := 0 to 20 do
  begin
    FGrid.Cells[0, i + 1] := IntToStr(i + 1);
    FGrid.Cells[1, i + 1] := IntToStr(YB[i] - 3 * N[YN[i]]);
    FGrid.Cells[2, i + 1] := IntToStr(X1B[i] - 2 * N[X1N[i]]);
    FGrid.Cells[3, i + 1] := IntToStr(X2B[i] + N[X2N[i]]);
    FGrid.Cells[4, i + 1] := IntToStr(X3B[i] - N[X3N[i]]);
  end;
  if Sender <> nil then Calculate(nil);
end;

function TForm1.ReadData(out D: TMat; out Msg: string): Boolean;
var
  r, c, n, cnt: Integer;
  v: Double;
  empty, anyEmpty: Boolean;
  Row: array[0..3] of Double;
begin
  Result := False;
  Msg := '';
  SetLength(D, 4);
  for c := 0 to 3 do SetLength(D[c], 0);
  n := 0;
  for r := 1 to FGrid.RowCount - 1 do
  begin
    cnt := 0;
    anyEmpty := False;
    for c := 1 to 4 do
    begin
      empty := Trim(FGrid.Cells[c, r]) = '';
      if empty then
        anyEmpty := True
      else
      begin
        Inc(cnt);
        if not ParseF(FGrid.Cells[c, r], v) then
        begin
          Msg := Format('Некоректне число в рядку %d, стовпець %d.', [r, c]);
          Exit;
        end;
        Row[c - 1] := v;
      end;
    end;
    if cnt = 0 then Continue;
    if anyEmpty then
    begin
      Msg := Format('Рядок %d заповнено не повністю.', [r]);
      Exit;
    end;
    Inc(n);
    for c := 0 to 3 do
    begin
      SetLength(D[c], n);
      D[c][n - 1] := Row[c];
    end;
  end;
  if n < 6 then
  begin
    Msg := 'Потрібно щонайменше 6 спостережень.';
    Exit;
  end;
  Result := True;
end;

procedure TForm1.Calculate(Sender: TObject);
var
  D, Rfull, Rxx, C: TMat;
  n, m, i, j, k, a, df2: Integer;
  alpha, tc, tcP, fcM, fcF, chi, chiC, detX, lnDet, detFull, R2, Rm, Fm, R2adj: Double;
  r, t, rp, bestR2, r2old, Fp, Fc: Double;
  Ok: Boolean;
  Msg: string;
  sig, keep: array[1..3] of Boolean;
  pr, pt: array[0..2, 0..2] of Double;
  Sel, Cols: TArray<Integer>;
  B: TVec;
  bestJ: Integer;
  added: Boolean;
  recommended: string;
begin
  if not ReadData(D, Msg) then
  begin
    ShowMessage(Msg);
    Exit;
  end;
  if (not ParseF(FEditAlpha.Text, alpha)) or (alpha <= 0) or (alpha >= 1) then
  begin
    ShowMessage('Рівень значущості має бути в межах (0; 1), наприклад 0.05');
    Exit;
  end;

  n := Length(D[0]);
  m := 3;
  FMemo.Lines.BeginUpdate;
  try
    FMemo.Clear;
    Say('ЛАБОРАТОРНА РОБОТА № 6. ПРОВЕДЕННЯ КОРЕЛЯЦІЙНОГО АНАЛІЗУ');
    Say(Format('Варіант %s | n = %d спостережень | m = %d пояснюючих змінних | α = %.3f',
      [FCombo.Text, n, m, alpha]));
    Say(Format('N1=%d, N2=%d, N3=%d, N4=%d',
      [VarTable[FCombo.ItemIndex, 1], VarTable[FCombo.ItemIndex, 2],
       VarTable[FCombo.ItemIndex, 3], VarTable[FCombo.ItemIndex, 4]]));
    Say(StringOfChar('=', 90));

    { ---- 1. Описова статистика ---- }
    Say;
    Say('1. СЕРЕДНІ ЗНАЧЕННЯ ТА СТАНДАРТНІ ВІДХИЛЕННЯ  (Excel: СРЗНАЧ, СТАНДОТКЛОН)');
    Say(Format('%-6s %14s %14s', ['', 'Середнє', 'Ст. відхилення']));
    for i := 0 to 3 do
      Say(Format('%-6s %14.4f %14.4f', [VarNames[i], AvgOf(D[i]), SdOf(D[i])]));

    { ---- 2. Кореляційна матриця ---- }
    SetLength(Rfull, 4);
    for i := 0 to 3 do
    begin
      SetLength(Rfull[i], 4);
      for j := 0 to 3 do
        if i = j then Rfull[i][j] := 1 else Rfull[i][j] := CorrOf(D[i], D[j]);
    end;
    SetLength(Rxx, 3);
    for i := 0 to 2 do
    begin
      SetLength(Rxx[i], 3);
      for j := 0 to 2 do Rxx[i][j] := Rfull[i + 1][j + 1];
    end;

    Say;
    Say('2. МАТРИЦЯ ПАРНИХ КОЕФІЦІЄНТІВ КОРЕЛЯЦІЇ  (Excel: КОРРЕЛ)  r = (1/(n-1)) X*ᵀ·X*');
    Say(Format('%-6s %10s %10s %10s %10s', ['', 'Y', 'X1', 'X2', 'X3']));
    for i := 0 to 3 do
      Say(Format('%-6s %10.4f %10.4f %10.4f %10.4f',
        [VarNames[i], Rfull[i][0], Rfull[i][1], Rfull[i][2], Rfull[i][3]]));

    { ---- 3. Значущість парних коефіцієнтів ---- }
    tcP := TCrit(alpha, n - 2);
    Say;
    Say('3. ЗНАЧУЩІСТЬ ПАРНИХ КОЕФІЦІЄНТІВ  t = r·√(n-2)/√(1-r²)');
    Say(Format('   tкр(α=%.3f; k=n-2=%d) = %.4f   (Excel: СТЬЮДРАСПОБР)', [alpha, n - 2, tcP]));
    for j := 1 to 3 do
    begin
      r := Rfull[0][j];
      t := SafeT(r, n - 2);
      sig[j] := Abs(t) > tcP;
      Say(Format('   r(Y,%s) = %8.4f | |t| = %8.4f | зв''язок %-9s | %s',
        [VarNames[j], r, Abs(t), Strength(r),
         IfThen(sig[j], 'ЗНАЧУЩИЙ (фактор впливає)', 'не значущий')]));
    end;

    { ---- 4. Множинний коефіцієнт кореляції ---- }
    detFull := MatDet(Rfull);
    detX := MatDet(Rxx);
    R2 := 0;
    if detX <> 0 then R2 := 1 - detFull / detX;
    if R2 < 0 then R2 := 0;
    if R2 > 1 then R2 := 1;
    Rm := Sqrt(R2);
    R2adj := 1 - (1 - R2) * (n - 1) / (n - m - 1);
    if 1 - R2 < 1E-12 then Fm := 1E9
    else Fm := (R2 / m) / ((1 - R2) / (n - m - 1));
    fcM := FCrit(alpha, m, n - m - 1);
    Say;
    Say('4. МНОЖИННИЙ КОЕФІЦІЄНТ КОРЕЛЯЦІЇ ТА ДЕТЕРМІНАЦІЇ');
    Say('   R² = 1 - det(r_повна)/det(r_xx),  F = (R²/m) / ((1-R²)/(n-m-1))');
    Say(Format('   det(r_повна) = %.6f ;  det(r_xx) = %.6f  (Excel: МОПРЕД)', [detFull, detX]));
    Say(Format('   Множинний коефіцієнт кореляції   R  = %.4f', [Rm]));
    Say(Format('   Коефіцієнт детермінації          R² = %.4f  (скоригований: %.4f)', [R2, R2adj]));
    Say(Format('   F = %.4f ; Fкр(α=%.3f; k1=%d; k2=%d) = %.4f  (Excel: FРАСПОБР)',
      [Fm, alpha, m, n - m - 1, fcM]));
    if Fm > fcM then
      Say('   Висновок: R та R² ЗНАЧУЩІ, модель в цілому адекватна (F > Fкр).')
    else
      Say('   Висновок: R та R² НЕ значущі (F ≤ Fкр).');

    { ---- 5. Алгоритм Фаррара-Глобера ---- }
    Say;
    Say('5. АЛГОРИТМ ФАРРАРА-ГЛОБЕРА (дослідження мультиколінеарності)');
    if detX < 1E-300 then detX := 1E-300;
    lnDet := Ln(detX);
    chi := -(n - 1 - (2 * m + 5) / 6) * lnDet;
    chiC := ChiCrit(alpha, m * (m - 1) div 2);
    Say('   5.1. Критерій χ² = -[n-1-(2m+5)/6]·ln(det r)');
    Say(Format('        det r = %.6f ; ln(det r) = %.4f', [detX, lnDet]));
    Say(Format('        χ² = %.4f ; χ²кр(α=%.3f; k=%d) = %.4f  (Excel: ХИ2ОБР)',
      [chi, alpha, m * (m - 1) div 2, chiC]));
    if chi > chiC then
      Say('        χ² > χ²кр: у масиві пояснюючих змінних ІСНУЄ мультиколінеарність.')
    else
      Say('        χ² ≤ χ²кр: мультиколінеарність у масиві факторів не виявлена.');

    for i := 0 to 2 do
      for j := 0 to 2 do
      begin
        pr[i, j] := 0;
        pt[i, j] := 0;
      end;

    C := MatInv(Rxx, Ok);
    tc := TCrit(alpha, n - m);
    fcF := FCrit(alpha, m - 1, n - m);
    if not Ok then
    begin
      Say;
      Say('   Матриця r_xx вироджена (існує точна лінійна залежність між факторами).');
    end
    else
    begin
      Say;
      Say('   5.2. Обернена матриця C = r⁻¹  (Excel: МОБР)');
      for i := 0 to 2 do
        Say(Format('        %12.4f %12.4f %12.4f', [C[i][0], C[i][1], C[i][2]]));
      Say;
      Say('   5.3. F-критерії  Fk = (Ckk - 1)·(n-m)/(m-1)');
      Say(Format('        Fкр(α=%.3f; k1=%d; k2=%d) = %.4f', [alpha, m - 1, n - m, fcF]));
      for k := 0 to 2 do
        Say(Format('        F(%s) = %9.4f  %s',
          [VarNames[k + 1], (C[k][k] - 1) * (n - m) / (m - 1),
           IfThen((C[k][k] - 1) * (n - m) / (m - 1) > fcF,
             '> Fкр: мультиколінеарна з іншими змінними',
             '≤ Fкр: не мультиколінеарна')]));
      Say;
      Say('   5.4. Частинні коефіцієнти кореляції  r(kj.s) = -Ckj/√(Ckk·Cjj)');
      Say('        та t-критерії  t = r·√(n-m)/√(1-r²)');
      Say(Format('        tкр(α=%.3f; k=n-m=%d) = %.4f', [alpha, n - m, tc]));
      for k := 0 to 1 do
        for j := k + 1 to 2 do
        begin
          rp := -C[k][j] / Sqrt(C[k][k] * C[j][j]);
          pr[k, j] := rp;
          pt[k, j] := SafeT(rp, n - m);
          Say(Format('        r(%s%s) = %8.4f (%-8s) | |t| = %8.4f | %s',
            [VarNames[k + 1], VarNames[j + 1], rp, Strength(rp), Abs(pt[k, j]),
             IfThen(Abs(pt[k, j]) > tc,
               '> tкр: пара мультиколінеарна', '≤ tкр: пара не мультиколінеарна')]));
        end;
    end;

    { ---- 6. Відбір факторів ---- }
    Say;
    Say('6. ВИСНОВКИ ТА ВІДБІР ФАКТОРІВ ДЛЯ РЕГРЕСІЙНОГО РІВНЯННЯ');
    for j := 1 to 3 do keep[j] := sig[j];
    if Ok then
      for k := 0 to 1 do
        for j := k + 1 to 2 do
          if Abs(pt[k, j]) > tc then
          begin
            if Abs(Rfull[0][k + 1]) >= Abs(Rfull[0][j + 1]) then
              keep[j + 1] := False
            else
              keep[k + 1] := False;
          end;
    recommended := '';
    for j := 1 to 3 do
      if keep[j] then
      begin
        if recommended <> '' then recommended := recommended + ', ';
        recommended := recommended + VarNames[j];
      end;
    for j := 1 to 3 do
      Say(Format('   %s: %s', [VarNames[j],
        IfThen(not sig[j], 'парна кореляція з Y незначуща — виключається;',
          IfThen(keep[j], 'значущий вплив на Y, залишається;',
            'значущий, але дублює інший фактор (мультиколінеарність) — виключається;'))]));
    if recommended = '' then recommended := '(жоден фактор не відібрано)';
    Say('   Рекомендований набір факторів для регресії: ' + recommended);
    if chi > chiC then
      Say('   Оскільки мультиколінеарність існує, перед застосуванням 1МНК її слід усунути');
    if chi > chiC then
      Say('   (виключити дублюючі фактори, перейти до відносних величин або застосувати');
    if chi > chiC then
      Say('   метод головних компонент / покрокову регресію).');

    { ---- 7. Покрокова регресія ---- }
    Say;
    Say('7. ПОКРОКОВА РЕГРЕСІЯ (послідовне включення факторів за F-критерієм)');
    SetLength(Sel, 0);
    r2old := 0;
    k := 0;
    while Length(Sel) < 3 do
    begin
      bestJ := -1;
      bestR2 := -1;
      for j := 1 to 3 do
        if not InArr(Sel, j) then
        begin
          SetLength(Cols, Length(Sel) + 1);
          for a := 0 to High(Sel) do Cols[a] := Sel[a];
          Cols[High(Cols)] := j;
          if Regress(D, Cols, B, R2) and (R2 > bestR2) then
          begin
            bestR2 := R2;
            bestJ := j;
          end;
        end;
      if bestJ < 0 then Break;
      df2 := n - (Length(Sel) + 1) - 1;
      if df2 < 1 then Break;
      if 1 - bestR2 < 1E-12 then Fp := 1E9
      else Fp := (bestR2 - r2old) / (1 - bestR2) * df2;
      Fc := FCrit(alpha, 1, df2);
      added := Fp > Fc;
      Inc(k);
      Say(Format('   Крок %d: кандидат %s ; R² %.4f → %.4f ; F = %.4f ; Fкр(1;%d) = %.4f -> %s',
        [k, VarNames[bestJ], r2old, bestR2, Fp, df2, Fc,
         IfThen(added, 'ВКЛЮЧЕНО', 'не включається, зупинка')]));
      if not added then Break;
      SetLength(Sel, Length(Sel) + 1);
      Sel[High(Sel)] := bestJ;
      Regress(D, Sel, B, R2);
      r2old := R2;
      Say('           ' + Equation(B, Sel));
    end;
    if Length(Sel) = 0 then
      Say('   Жоден фактор не пройшов відбір.')
    else
    begin
      Regress(D, Sel, B, R2);
      Say('   Підсумкова модель: ' + Equation(B, Sel));
      Say(Format('   R² = %.4f', [R2]));
    end;

    Say;
    Say('   Порівняння оцінок параметрів моделі при різних наборах факторів');
    Say('   (демонстрація впливу мультиколінеарності на коефіцієнти):');
    for j := 1 to 3 do
    begin
      SetLength(Cols, 1);
      Cols[0] := j;
      if Regress(D, Cols, B, R2) then
        Say(Format('   %-28s R² = %.4f', [Equation(B, Cols), R2]));
    end;
    SetLength(Cols, 3);
    Cols[0] := 1; Cols[1] := 2; Cols[2] := 3;
    if Regress(D, Cols, B, R2) then
      Say(Format('   %-28s R² = %.4f', [Equation(B, Cols), R2]))
    else
      Say('   Регресія за всіма факторами неможлива (вироджена матриця).');

    { ---- 8. Інструменти Excel ---- }
    Say;
    Say('8. ВІДПОВІДНІСТЬ ФУНКЦІЯМ MS EXCEL (для звіту)');
    Say('   СРЗНАЧ, СТАНДОТКЛОН — середнє та стандартне відхилення;');
    Say('   КОВАР, КОРРЕЛ — коваріація та коефіцієнт парної кореляції;');
    Say('   НОРМАЛИЗАЦИЯ — нормалізація змінних;  ТРАНСП, МУМНОЖ — транспонування та множення матриць;');
    Say('   МОПРЕД, МОБР — визначник та обернена матриця;  LN — логарифм;');
    Say('   СТЬЮДРАСПОБР, FРАСПОБР, ХИ2ОБР — критичні значення розподілів Стьюдента, Фішера, χ²;');
    Say('   Надбудова «Аналіз даних» → «Кореляція», «Регресія».');
  finally
    FMemo.Lines.EndUpdate;
  end;
  FMemo.SelStart := 0;
  FMemo.SelLength := 0;
end;

procedure TForm1.SaveReport(Sender: TObject);
begin
  FSave.Filter := 'Текстовий файл (*.txt)|*.txt';
  FSave.DefaultExt := 'txt';
  FSave.FileName := 'Lab6_report.txt';
  if FSave.Execute then
    FMemo.Lines.SaveToFile(FSave.FileName, TEncoding.UTF8);
end;

procedure TForm1.SaveCsv(Sender: TObject);
var
  SL: TStringList;
  r, c: Integer;
  line: string;
begin
  FSave.Filter := 'CSV для Excel (*.csv)|*.csv';
  FSave.DefaultExt := 'csv';
  FSave.FileName := 'Lab6_data.csv';
  if not FSave.Execute then Exit;
  SL := TStringList.Create;
  try
    for r := 0 to FGrid.RowCount - 1 do
    begin
      line := '';
      for c := 0 to FGrid.ColCount - 1 do
      begin
        if c > 0 then line := line + ';';
        line := line + FGrid.Cells[c, r];
      end;
      SL.Add(line);
    end;
    SL.SaveToFile(FSave.FileName, TEncoding.UTF8);
  finally
    SL.Free;
  end;
end;

end.
