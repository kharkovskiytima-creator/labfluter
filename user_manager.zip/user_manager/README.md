# Лабораторна робота 1-2 — Flutter (MVVM)

Додаток «Користувачі»: список, додавання/редагування/видалення, фото через камеру або галерею, локальне збереження, темна/світла тема, анімації.

## Запуск

1. Встановити Flutter SDK, Android Studio (для iOS ще й Xcode).
2. У порожній папці виконати:
   ```
   flutter create user_manager
   ```
3. Замінити в створеному проєкті `pubspec.yaml` та папку `lib/` на файли з цього архіву.
4. Виконати `flutter pub get`.
5. Додати дозволи для камери/галереї:

**Android** — `android/app/src/main/AndroidManifest.xml` (всередину `<manifest>`, до `<application>`):
```xml
<uses-permission android:name="android.permission.CAMERA"/>
```

**iOS** — `ios/Runner/Info.plist` (всередину `<dict>`):
```xml
<key>NSCameraUsageDescription</key>
<string>Потрібен доступ до камери для фото профілю</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>Потрібен доступ до галереї для фото профілю</string>
```

6. `flutter run` (Android емулятор / iOS симулятор / телефон).

## Структура (MVVM)

```
lib/
├── main.dart                         # точка входу, Provider, теми
├── models/user.dart                  # Model
├── repositories/user_repository.dart # локальне сховище + файли фото
├── viewmodels/
│   ├── user_list_viewmodel.dart      # ViewModel: логіка користувачів
│   └── theme_viewmodel.dart          # ViewModel: тема
├── views/
│   ├── home_screen.dart              # View: список
│   └── user_form_screen.dart         # View: форма
└── widgets/
    ├── user_card.dart
    └── user_avatar.dart
```

## Оптимізація
- **Мінімізація рендерингів:** `context.select` (слухаємо лише потрібні поля), `const` віджети, `ValueKey`, окремий `UserCard`, `operator ==` у моделі.
- **Кешування:** `shared_preferences` (JSON), фото копіюються в постійну директорію додатка; зображення декодуються через `ResizeImage`.
- **Асинхронність:** усі операції зі сховищем і камерою — `async/await`.

## Нативний API
Камера та галерея — пакет `image_picker`.

## Додатково
- Темна/світла тема (збереження вибору, анімована іконка).
- Анімації: перехід між екранами (Fade+Slide), Hero для аватара, AnimatedSwitcher.
- Адаптивність: `SliverGridDelegateWithMaxCrossAxisExtent` (1 колонка на телефоні, кілька на планшеті), обмеження ширини форми.
