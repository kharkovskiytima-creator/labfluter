import 'dart:io';

import 'package:flutter/material.dart';

/// Аватар користувача. Зображення декодується в зменшеному розмірі
/// (ResizeImage), що економить пам'ять.
class UserAvatar extends StatelessWidget {
  const UserAvatar({
    super.key,
    required this.name,
    this.photoPath,
    this.radius = 28,
  });

  final String name;
  final String? photoPath;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final hasPhoto = photoPath != null && File(photoPath!).existsSync();

    return CircleAvatar(
      radius: radius,
      backgroundColor: scheme.primaryContainer,
      foregroundColor: scheme.onPrimaryContainer,
      backgroundImage: hasPhoto
          ? ResizeImage(FileImage(File(photoPath!)), width: 300)
          : null,
      child: hasPhoto
          ? null
          : Text(
              name.trim().isNotEmpty
                  ? name.trim().characters.first.toUpperCase()
                  : '?',
              style: TextStyle(fontSize: radius * 0.8),
            ),
    );
  }
}
