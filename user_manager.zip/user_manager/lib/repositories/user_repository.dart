import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/user.dart';

/// Локальне кешування даних (аналог AsyncStorage) + збереження фото.
/// Усі операції асинхронні.
class UserRepository {
  static const _key = 'users_v1';

  Future<List<User>> loadUsers() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    final list = jsonDecode(raw) as List<dynamic>;
    return list
        .map((e) => User.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> saveUsers(List<User> users) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _key,
      jsonEncode(users.map((u) => u.toJson()).toList()),
    );
  }

  /// Копіює фото з тимчасової директорії в постійне сховище додатка.
  Future<String> persistPhoto(String sourcePath) async {
    final dir = await getApplicationDocumentsDirectory();
    final name =
        '${DateTime.now().microsecondsSinceEpoch}${p.extension(sourcePath)}';
    final saved = await File(sourcePath).copy(p.join(dir.path, name));
    return saved.path;
  }
}
