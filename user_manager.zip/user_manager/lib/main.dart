import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'repositories/user_repository.dart';
import 'viewmodels/theme_viewmodel.dart';
import 'viewmodels/user_list_viewmodel.dart';
import 'views/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => UserListViewModel(UserRepository())..loadUsers(),
        ),
        ChangeNotifierProvider(create: (_) => ThemeViewModel()..load()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // select: перебудовуємо MaterialApp лише при зміні режиму теми.
    final mode = context.select<ThemeViewModel, ThemeMode>((vm) => vm.mode);

    return MaterialApp(
      title: 'Користувачі',
      debugShowCheckedModeBanner: false,
      themeMode: mode,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
          brightness: Brightness.dark,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
