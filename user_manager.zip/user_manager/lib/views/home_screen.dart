import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/user.dart';
import '../viewmodels/theme_viewmodel.dart';
import '../viewmodels/user_list_viewmodel.dart';
import '../widgets/user_card.dart';
import 'user_form_screen.dart';

/// Анімований перехід між екранами (додаткове завдання №2).
Route<T> animatedRoute<T>(Widget page) {
  return PageRouteBuilder<T>(
    transitionDuration: const Duration(milliseconds: 350),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, animation, __, child) {
      final curved =
          CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0, 0.08),
            end: Offset.zero,
          ).animate(curved),
          child: child,
        ),
      );
    },
  );
}

/// View: головний екран зі списком користувачів.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Користувачі'),
        actions: [
          IconButton(
            tooltip: 'Змінити тему',
            onPressed: () =>
                context.read<ThemeViewModel>().toggle(brightness),
            icon: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              transitionBuilder: (child, anim) => RotationTransition(
                turns: Tween<double>(begin: 0.75, end: 1).animate(anim),
                child: FadeTransition(opacity: anim, child: child),
              ),
              child: Icon(
                brightness == Brightness.dark
                    ? Icons.light_mode
                    : Icons.dark_mode,
                key: ValueKey(brightness),
              ),
            ),
          ),
        ],
      ),
      body: const _UserList(),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () =>
            Navigator.of(context).push(animatedRoute(const UserFormScreen())),
        icon: const Icon(Icons.person_add),
        label: const Text('Додати'),
      ),
    );
  }
}

class _UserList extends StatelessWidget {
  const _UserList();

  @override
  Widget build(BuildContext context) {
    // select: слухаємо лише потрібні поля ViewModel.
    final isLoading =
        context.select<UserListViewModel, bool>((vm) => vm.isLoading);
    final users =
        context.select<UserListViewModel, List<User>>((vm) => vm.users);

    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (users.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Список порожній.\nНатисніть «Додати», щоб створити користувача.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }

    // Адаптивність: на вузьких екранах 1 колонка, на широких — кілька.
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 480,
        mainAxisExtent: 92,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: users.length,
      itemBuilder: (context, index) {
        final user = users[index];
        return Dismissible(
          key: ValueKey(user.id),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 24),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.errorContainer,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.delete,
              color: Theme.of(context).colorScheme.onErrorContainer,
            ),
          ),
          onDismissed: (_) {
            final vm = context.read<UserListViewModel>();
            final messenger = ScaffoldMessenger.of(context);
            vm.deleteUser(user.id);
            messenger
              ..hideCurrentSnackBar()
              ..showSnackBar(
                SnackBar(
                  content: Text('«${user.name}» видалено'),
                  action: SnackBarAction(
                    label: 'Скасувати',
                    onPressed: () => vm.restoreUser(user, index),
                  ),
                ),
              );
          },
          child: UserCard(
            user: user,
            onTap: () => Navigator.of(context)
                .push(animatedRoute(UserFormScreen(user: user))),
          ),
        );
      },
    );
  }
}
