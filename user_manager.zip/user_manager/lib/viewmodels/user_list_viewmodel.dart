import 'dart:collection';

import 'package:flutter/foundation.dart';

import '../models/user.dart';
import '../repositories/user_repository.dart';

/// ViewModel: бізнес-логіка роботи з користувачами.
class UserListViewModel extends ChangeNotifier {
  UserListViewModel(this._repository);

  final UserRepository _repository;

  List<User> _users = [];
  bool _isLoading = true;

  UnmodifiableListView<User> get users => UnmodifiableListView(_users);
  bool get isLoading => _isLoading;

  Future<void> loadUsers() async {
    _isLoading = true;
    notifyListeners();
    _users = await _repository.loadUsers();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> addUser({
    required String name,
    required String email,
    required String phone,
    String? photoSourcePath,
  }) async {
    String? photo;
    if (photoSourcePath != null) {
      photo = await _repository.persistPhoto(photoSourcePath);
    }
    final user = User(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      name: name,
      email: email,
      phone: phone,
      photoPath: photo,
    );
    _users = [..._users, user];
    notifyListeners();
    await _repository.saveUsers(_users);
  }

  Future<void> updateUser(
    User old, {
    required String name,
    required String email,
    required String phone,
    String? photoSourcePath,
    bool removePhoto = false,
  }) async {
    String? photo = old.photoPath;
    if (photoSourcePath != null) {
      photo = await _repository.persistPhoto(photoSourcePath);
    } else if (removePhoto) {
      photo = null;
    }
    final updated = User(
      id: old.id,
      name: name,
      email: email,
      phone: phone,
      photoPath: photo,
    );
    _users = [
      for (final u in _users) u.id == old.id ? updated : u,
    ];
    notifyListeners();
    await _repository.saveUsers(_users);
  }

  Future<void> deleteUser(String id) async {
    _users = _users.where((u) => u.id != id).toList();
    notifyListeners();
    await _repository.saveUsers(_users);
  }

  /// Для "Скасувати" після видалення.
  Future<void> restoreUser(User user, int index) async {
    final copy = [..._users];
    copy.insert(index.clamp(0, copy.length), user);
    _users = copy;
    notifyListeners();
    await _repository.saveUsers(_users);
  }
}
