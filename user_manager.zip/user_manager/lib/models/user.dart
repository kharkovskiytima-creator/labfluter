/// Model: модель даних користувача (незмінний об'єкт).
class User {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String? photoPath;

  const User({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    this.photoPath,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'phone': phone,
        'photoPath': photoPath,
      };

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json['id'] as String,
        name: json['name'] as String,
        email: json['email'] as String,
        phone: json['phone'] as String,
        photoPath: json['photoPath'] as String?,
      );

  // Порівняння за значенням: допомагає уникати зайвих перерендерів.
  @override
  bool operator ==(Object other) =>
      other is User &&
      other.id == id &&
      other.name == name &&
      other.email == email &&
      other.phone == phone &&
      other.photoPath == photoPath;

  @override
  int get hashCode => Object.hash(id, name, email, phone, photoPath);
}
